var collection = ["apples", "oranges"];
export function addNewItem(newItem) {
  collection.push(newItem);
}
export function getNumItem() {
  return collection.length;
}
